/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Arrays;

import java.util.Scanner;

/**
 *
 * @author Sebas
 */
public class T_1 {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        int[] numeros = new int[10];

        for (int i = 0; i < 10; i++) {
            System.out.print("Digite el numero " + i + ":");
            numeros[i] = entrada.nextInt();
        }

        for (int i = 9; i >= 0; i--) {
            System.out.print(numeros[i] + " ");
        }

    }
}
