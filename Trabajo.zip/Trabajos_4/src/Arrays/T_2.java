/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Arrays;

import java.util.Scanner;

/**
 *
 * @author Sebas
 */
public class T_2 {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        int[] numeros = new int[10];

        for (int i = 0; i < 10; i++) {
            System.out.print("Digite el numero " + i + ":");
            numeros[i] = entrada.nextInt();
        }
        int maximo = numeros[0];
        int minimo = numeros[0];

        for (int i = 1; i < numeros.length; i++) {
            if (numeros[i] > maximo) {
                maximo = numeros[i];
            }
            if (numeros[i] < minimo) {
                minimo = numeros[i];
            }

        }
        for (int i = 0; i < numeros.length; i++) {
            System.out.print(numeros[i] + " ");
            if (numeros[i] == maximo) {
                System.out.print("máximo");
            }
            if (numeros[i] == minimo) {
                System.out.print("mínimo");
            }
            System.out.println();
        }
    }
}
