/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package continuacion;

import java.util.Scanner;

/**
 *
 * @author Sebas
 */
public class T_2 {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        System.out.print("Digite la cantidad de numeros :");
        int cannumeros = entrada.nextInt();

        int mayores = 0;
        int menores = 0;
        int iguales = 0;

        for (int i = 1; i <= cannumeros; i++) {

            System.out.print(("Ingrese el numero " + i + ":"));
            int numero = entrada.nextInt();

            if (numero < 0) {

                menores++;

            } else if (numero > 0) {

                mayores++;
            } else {

                iguales++;
            }

        }
        System.out.print("La cantidad de numeros mayores a 0 es: " + mayores);
        System.out.print("La cantidad de numeros menores a 0 es: " + menores);
        System.out.print("La cantidad de numeros iguales a 0 es: " + iguales);
    }
}
