/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package continuacion;

import java.util.Scanner;

/**
 *
 * @author Sebas
 */
public class T_3 {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        char p;

        do {
            System.out.print("Digite caracteres:");
            p = entrada.nextLine().charAt(0);

            if (p == 'a' || p == 'e' || p == 'i' || p == 'o' || p == 'u' || p == 'A' || p == 'E' || p == 'I' || p == 'O' || p == 'U') {

                System.out.println("ES UNA VOCAL");
            } else if (p != ' ') {

                System.out.println(" NO ES UNA VOCAL");

            }

        } while (p != ' ');
        System.out.println("Programa terminado.");
        entrada.close();
    }
}
