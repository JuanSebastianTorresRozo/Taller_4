/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package continuacion;

import java.util.Scanner;

/**
 *
 * @author Sebas
 */
public class T_7 {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        System.out.print("Digite el total de la compra:");
        int totalVenta = entrada.nextInt();

        System.out.print("Digite el pago mensual:");
        int pagoMensual = entrada.nextInt();

        int pagoTotal = totalVenta / pagoMensual;

        System.out.println("La cantidad que va a pagar sera de : " + pagoTotal + " Pesos");

        double total = 0;
        double pago = 10;

        for (int i = 0; i < pagoMensual; i++) {
            total += pago;
            pago *= 2;
        }
        System.out.printf("El total a pagar después de los %d meses es: %.2f$\n", pagoMensual, total);

    }
}
