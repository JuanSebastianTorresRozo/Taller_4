/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package continuacion;

import java.util.Scanner;

/**
 *
 * @author Sebas
 */
public class T_4 {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        System.out.print("Digite el primer numero:");
        int numero1 = entrada.nextInt();

        System.out.print("Digite el segundo numero:");
        int numero2 = entrada.nextInt();

        int x = numero1;

        while (x <= numero2) {
            if (x % 2 == 0) {
                System.out.println("Los numeros pares seran: " + x);
            }
            x++;

        }

    }
}
