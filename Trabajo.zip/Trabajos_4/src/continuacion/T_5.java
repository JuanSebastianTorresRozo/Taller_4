/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package continuacion;

import java.util.Scanner;

/**
 *
 * @author Sebas
 */
public class T_5 {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);
        int numero, suma = 0, dentro = 0, fuera = 0;
        boolean igualLimite = false, limiteCorrecto = false;

        System.out.print("Digite el limite inferior:");
        int limiteI = entrada.nextInt();

        System.out.print("Digite el limite Superior:");
        int limiteS = entrada.nextInt();

        if (limiteI >= limiteS) {

            System.out.println("¡¡¡VUELVE A INGRESAR LOS LIMITES, ACUERDATE QUE EL INFERIOR DEBE SER MENOR QUE LE SUPERIOR!!!!");

            System.out.print("Digite el limite inferior:");
            limiteI = entrada.nextInt();

            System.out.print("Digite el limite Superior:");
            limiteS = entrada.nextInt();

        }
        do {
            System.out.print("Introduce un número (0 para terminar):");
            numero = entrada.nextInt();
            if (numero == limiteI || numero == limiteS) {
                igualLimite = true;
            }
            if (numero > limiteI && numero < limiteS) {
                suma += numero;
                dentro++;
            } else {
                fuera++;
            }
        } while (numero != 0);

        System.out.println("La suma de los números dentro del intervalo es: " + suma);
        System.out.println("Hay " + dentro + " números dentro del intervalo.");
        System.out.println("Hay " + fuera + " números fuera del intervalo.");
        if (igualLimite) {
            System.out.println("Se ha introducido al menos un número igual a los límites del intervalo.");
        }

    }
}
