/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package continuacion;

import java.util.Scanner;

/**
 *
 * @author Sebas
 */
public class T_9 {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        System.out.print("Digite la cantidad de numeros primos que quiere mostrar: ");
        int numero = entrada.nextInt();
        int count = 0;
        int i = 2;

        while (count < numero) {
            boolean Primo = true;
            for (int j = 2; j < i; j++) {
                if (i % j == 0) {
                    Primo = false;
                    break;
                }
            }
            if (Primo) {
                System.out.print(i + " ");
                count++;
            }

            i++;
        }

    }

}
