/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package continuacion;


import java.util.Scanner;

/**
 *
 * @author Sebas
 */
public class T_8 {

    public static void main(String[] args)  {

         Scanner scanner = new Scanner(System.in);

        boolean detenido = true;
        int horas = 0, minutos = 0, segundos = 0;

        System.out.println("Presione Enter para detener el cronómetro.");

        while (detenido) {
            try {
                Thread.sleep(1000); 
                segundos++;
                if (segundos == 60) {
                    segundos = 0;
                    minutos++;
                    if (minutos == 60) {
                        minutos = 0;
                        horas++;
                    }
                }
                System.out.printf("%02d:%02d:%02d\n", horas, minutos, segundos);
                if (System.in.available() > 0) {
                    String entrada = scanner.nextLine();
                    if (entrada.equals("")) {
                        detenido = false;
                    }
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (java.io.IOException e) {
                e.printStackTrace();
            }
        }

        System.out.println("Cronómetro detenido.");
    }
    }


