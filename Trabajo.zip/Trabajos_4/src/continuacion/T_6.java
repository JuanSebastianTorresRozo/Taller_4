/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package continuacion;

import java.util.Scanner;

/**
 *
 * @author Sebas
 */
public class T_6 {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        System.out.print("Digite la base:");
        double base = entrada.nextDouble();

        System.out.print("Digite el exponente:");
        int exponente = entrada.nextInt();

        double resultado = 1;

        for (int i = 1; i < exponente; i++) {

            resultado *= base;

        }
        System.out.println(base + " elevado a la potencia " + exponente + " es igual a " + resultado);
    }
}

