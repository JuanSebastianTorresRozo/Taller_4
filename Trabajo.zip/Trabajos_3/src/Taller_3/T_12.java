/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Taller_3;

import java.util.Scanner;

/**
 *
 * @author Sebas
 */
public class T_12 {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        System.out.print("Ingrese la duracion de la llamada en minutos: ");
        int duracion = entrada.nextInt();

        System.out.print("Ingrese el día de la semana (lunes a domingo): ");
        String dia = entrada.next().toLowerCase();

        System.out.print("Ingrese el turno (mañana o tarde): ");
        String turno = entrada.next().toLowerCase();

        double costo = 0;

        if (duracion <= 5) {

            costo = duracion * 1.0;

        } else if (duracion <= 8) {

            costo = 5 + (duracion - 5) * 0.8;

        } else if (duracion <= 10) {

            costo = 7.4 + (duracion - 8) * 0.7;

        } else {

            costo = 8.8 + (duracion - 10) * 0.5;

        }

        double impuesto = 0;
        if (dia.equals("domingo")) {
            impuesto = costo * 0.03;
        } else if (turno.equals("mañana")) {
            impuesto = costo * 0.15;
        } else {
            impuesto = costo * 0.1;
        }

        double total = costo + impuesto;
        System.out.println("El costo total de la llamada es de " + total + " euros.");

    }
}
