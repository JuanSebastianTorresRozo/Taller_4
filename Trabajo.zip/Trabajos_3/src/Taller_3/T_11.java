/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Taller_3;

import java.util.Scanner;

/**
 *
 * @author Sebas
 */
public class T_11 {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int alumnos = 0;
        double costoPorAlumno = 0;
        double total = 0;

        System.out.print("Ingrese la cantidad de alumnos que van asistir: ");
        alumnos = entrada.nextInt();

        if (alumnos >= 100) {

            costoPorAlumno = 65;

        } else if (alumnos >= 50) {

            costoPorAlumno = 70;

        } else if (alumnos >= 30) {

            costoPorAlumno = 95;

        }else {
        
            total=  4000;
            
        }
        if (costoPorAlumno > 0) {
            total = alumnos * costoPorAlumno;
        }
        
        System.out.println("El costo pro alumno del viaje sera de : "+ costoPorAlumno  + "Euros");
        System.out.println("El costo total del viaje sera de : "+ total + "Euros");
        
    }

}
