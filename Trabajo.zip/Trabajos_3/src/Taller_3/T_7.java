/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Taller_3;

import java.util.Scanner;

/**
 *
 * @author Sebas
 */
public class T_7 {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        System.out.print("Digite el punto en X y el punto en Y:");
        double x1 = entrada.nextDouble();
        double y1 = entrada.nextDouble();

        System.out.print("Digite el radio de la circunferencia: :");
        double r1 = entrada.nextDouble();

        System.out.print("Digite el punto en X2 y el punto en Y2 :");
        double x2 = entrada.nextDouble();
        double y2 = entrada.nextDouble();

        System.out.print("Digite el radio de la circunferencia: :");
        double r2 = entrada.nextDouble();

        double distancia = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));

        if (distancia > r1 + r2) {
            System.out.println("Las circunferencias son exteriores.");
        } else if (distancia == r1 + r2) {
            System.out.println("Las circunferencias son tangentes exteriores.");
        } else if (distancia < Math.abs(r1 - r2)) {
            System.out.println("Las circunferencias son interiores.");
        } else if (distancia == Math.abs(r1 - r2)) {
            System.out.println("Las circunferencias son tangentes interiores.");
        } else if (distancia == 0 && r1 == r2) {
            System.out.println("Las circunferencias son concéntricas.");
        } else {
            System.out.println("Las circunferencias son secantes.");
        }

    }
}
