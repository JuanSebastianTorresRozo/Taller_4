/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Taller_3;

import java.util.Scanner;

/**
 *
 * @author Sebas
 */
public class T_2 {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        System.out.print("Digite el numero :");
        int numero1 = entrada.nextInt();

        if (numero1 % 2 == 0) {
            System.out.print("El numero es par ");
        } else {

            System.out.print("El  numero es impar");
        }
    }
}
