/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Taller_3;

import java.util.Scanner;

/**
 *
 * @author Sebas
 */
public class T_4 {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);
        System.out.print("Digite la cadena de texto: ");
        String palabra = entrada.nextLine();

        boolean hayMayuscula = false;
        for (int i = 0; i < palabra.length(); i++) {
            char letra = palabra.charAt(i);
            if (Character.isUpperCase(letra)) {
                hayMayuscula = true;
                System.out.println(letra + " es una letra mayúscula");
            }
        }

        if (!hayMayuscula) {
            System.out.println("No se encontraron letras mayúsculas.");
        }
    }

}
