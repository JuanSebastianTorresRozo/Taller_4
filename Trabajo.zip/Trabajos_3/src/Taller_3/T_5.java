/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Taller_3;

import java.util.Scanner;

/**
 *
 * @author Sebas
 */
public class T_5 {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        System.out.print("Ingrese el número base: ");
        double base = entrada.nextDouble();
        System.out.print("Ingrese el exponente: ");
        int exponente = entrada.nextInt();

        double resultado = 0;
        switch (exponente) {
            case 0:
                resultado = 1;
                break;
            case 1:
                resultado = base;
                break;
            default:
                if (exponente > 1) {
                    resultado = Math.pow(base, exponente);
                } else {
                    resultado = 1 / Math.pow(base, -exponente);
                }
                break;
        }

        System.out.println("El resultado es: " + resultado);
    }

}

