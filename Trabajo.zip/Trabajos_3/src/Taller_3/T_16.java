/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Taller_3;

import java.util.Scanner;

/**
 *
 * @author Sebas
 */
public class T_16 {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        double peso, costo;
        int zona;

        System.out.print("Ingrese el peso del paquete (en kg): ");
        peso = entrada.nextDouble();

        if (peso > 5) {
            System.out.println("Lo sentimos, no se pueden transportar paquetes de más de 5kg.");
        } else {
            System.out.println("Ingrese la zona a la que va dirigido el paquete:");
            System.out.println("1. América del Norte");
            System.out.println("2. América Central");
            System.out.println("3. América del Sur");
            System.out.println("4. Europa");
            System.out.println("5. Asia");
            zona = entrada.nextInt();

            if (zona == 1) {
                costo = peso * 24.00;
                System.out.println("El costo del envío es de " + costo + " euros.");
            } else if (zona == 2) {
                costo = peso * 20.00;
                System.out.println("El costo del envío es de " + costo + " euros.");
            } else if (zona == 3) {
                costo = peso * 21.00;
                System.out.println("El costo del envío es de " + costo + " euros.");
            } else if (zona == 4) {
                costo = peso * 10.00;
                System.out.println("El costo del envío es de " + costo + " euros.");
            } else if (zona == 5) {
                costo = peso * 18.00;
                System.out.println("El costo del envío es de " + costo + " euros.");
            } else {
                System.out.println("La zona ingresada es inválida.");
            }
        }
    }
}
